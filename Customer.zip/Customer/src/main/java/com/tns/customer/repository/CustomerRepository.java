package com.tns.customer.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.tns.customer.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {
}